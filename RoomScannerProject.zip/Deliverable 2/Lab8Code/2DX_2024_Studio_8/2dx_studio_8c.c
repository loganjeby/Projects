#include <stdint.h>
#include "PLL.h"
#include "SysTick.h"
#include "uart.h"
#include "onboardLEDs.h"
#include "tm4c1294ncpdt.h"
#include "VL53L1X_api.h"

#define I2C_MCS_ACK             0x00000008  // Data Acknowledge Enable
#define I2C_MCS_DATACK          0x00000008  // Acknowledge Data
#define I2C_MCS_ADRACK          0x00000004  // Acknowledge Address
#define I2C_MCS_STOP            0x00000004  // Generate STOP
#define I2C_MCS_START           0x00000002  // Generate START
#define I2C_MCS_ERROR           0x00000002  // Error
#define I2C_MCS_RUN             0x00000001  // I2C Master Enable
#define I2C_MCS_BUSY            0x00000001  // I2C Busy
#define I2C_MCR_MFE             0x00000010  // I2C Master Function Enable

#define MAXRETRIES              5           // number of receive attempts before giving up

void I2C_Init(void);
void PortH_Init(void);
void PortJ_Init(void);
void SpinMotor(int* fullSteps, float* motorDegrees);
void SpinMotorCCW(int* fullSteps, float* motorDegrees);
void dataButton(void);
void stepperScanButton(void);

uint16_t	dev = 0x29;			//address of the ToF sensor as an I2C slave peripheral
int status = 0;
_Bool dataButt = 1;
_Bool stepperScanButt = 1;
int scans = 0;
int desiredScans = 3;

int main(void) {
	int input = 0;
	int fullSteps = 0;
	float motorDegrees = 0;

  	uint8_t byteData, sensorState=0, myByteArray[10] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF} , i=0;
  	uint16_t wordData;
  	uint16_t Distance;
  	uint16_t SignalRate;
  	uint16_t AmbientRate;
  	uint16_t SpadNum; 
  	uint8_t RangeStatus;
  	uint8_t dataReady;

	//initialize
	PLL_Init();	
	SysTick_Init();
	onboardLEDs_Init();
	PortH_Init();
	PortJ_Init();	
	I2C_Init();
	UART_Init();
	
	for(int i = 0; i < 10; i++){
		GPIO_PORTN_DATA_R ^= 0b00000010; 								// Prove bus speed
		SysTick_Wait10ms(50);														//.05s delay
		GPIO_PORTN_DATA_R ^= 0b00000010;		
		SysTick_Wait10ms(50);														//.05s delay
	}
	
	// hello world!
	while(1){
		input = UART_InChar();
		if (input == 's')
			break;
	}
	
	UART_printf("Program Begins\r\n");
	int mynumber = 1;
	sprintf(printf_buffer,"ebyl1 Final Code %d\r\n",mynumber);
	UART_printf(printf_buffer);


	/* Those basic I2C read functions can be used to check your own I2C functions */
	//1st milestone
	status = VL53L1_RdByte(dev, 0x010F, &byteData); //for model ID (0xEA)
	sprintf(printf_buffer,"Model_ID: 0x%x\r\n", byteData);
	UART_printf(printf_buffer);
	
	status = VL53L1_RdByte(dev, 0x0110, &byteData); //for module type (0xCC)
	sprintf(printf_buffer,"Module_type: 0x%x\r\n", byteData);
	UART_printf(printf_buffer);
	
	status = VL53L1_RdWord(dev, 0x010F, &wordData); //for both model ID and type
	sprintf(printf_buffer,"(Model_ID, Module_Type): 0x%x\r\n", wordData);
	UART_printf(printf_buffer);

	// 1 Wait for device ToF booted
	while(sensorState==0){
		status = VL53L1X_BootState(dev, &sensorState);
		SysTick_Wait10ms(10);
  	}
	UART_printf("ToF Chip Booted!\r\n Please Wait...\r\n");
	
	status = VL53L1X_ClearInterrupt(dev); /* clear interrupt has to be called to enable next interrupt*/
	
  	/* 2 Initialize the sensor with the default setting  */
  	status = VL53L1X_SensorInit(dev);
	Status_Check("SensorInit", status);
	
	status = VL53L1X_SetDistanceMode(dev, 2); /* 1=short, 2=long */

  	status = VL53L1X_StartRanging(dev);   // 4 This function has to be called to enable the ranging

	while(scans < desiredScans){
		while(1){
			input = UART_InChar();
			if (input == 's')
				break;
		}
		while(fullSteps < 2048){ // 360 degree rotation
			dataButton();
			stepperScanButton();
			if (stepperScanButt == 1){
				SpinMotor(&fullSteps, &motorDegrees);
			}
			else{
				UART_printf("St\n");
			}
			//motorDegrees is the amount of degrees rotated by motor	
			if (motorDegrees >= 5.625) { // get data every 5.625 degrees - 64 turns
				//Read sensor data here//
				//wait until data is ready
				if (stepperScanButt == 1){
					GPIO_PORTF_DATA_R = 0b00010000;
					while (dataReady == 0){
						status = VL53L1X_CheckForDataReady(dev, &dataReady);
						FlashLED3(1);
						VL53L1_WaitMs(dev, 5);
					}
					dataReady = 0;
			
					//7 read the data values from ToF sensor
					status = VL53L1X_GetRangeStatus(dev, &RangeStatus);
					status = VL53L1X_GetDistance(dev, &Distance);	// The Measured Distance value
					status = VL53L1X_GetSignalRate(dev, &SignalRate);
					status = VL53L1X_GetAmbientRate(dev, &AmbientRate);
					status = VL53L1X_GetSpadNb(dev, &SpadNum);
								
					status = VL53L1X_ClearInterrupt(dev); /* 8 clear interrupt has to be called to enable next interrupt*/
					GPIO_PORTF_DATA_R = 0b00000000;
				}
				else{
					UART_printf("Sc\n");
				}
				if (dataButt == 1){
					GPIO_PORTF_DATA_R = 0b00000001;
					// print the resulted readings to UART
					//sprintf(printf_buffer,"%u, %u, %u, %u, %u\r\n", RangeStatus, Distance, SignalRate, AmbientRate,SpadNum);
					sprintf(printf_buffer,"%u\n",Distance);
					UART_printf(printf_buffer);
					SysTick_Wait10ms(50);
					//End of reading data
					GPIO_PORTF_DATA_R = 0b00000000;
				}
				else{
					UART_printf("D\n");
				}
				motorDegrees = 0;
			}
			dataButton();
			stepperScanButton();
		}
		while(1){
			SpinMotorCCW(&fullSteps, &motorDegrees);
			if(fullSteps == 0){
				break;
			}
		}
	}
	
	VL53L1X_StopRanging(dev);
  	while(1) {}
}

void I2C_Init(void){
  	SYSCTL_RCGCI2C_R |= SYSCTL_RCGCI2C_R0;           													// activate I2C0
  	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R1;          												// activate port B
  	while((SYSCTL_PRGPIO_R&0x0002) == 0){};																		// ready?

    GPIO_PORTB_AFSEL_R |= 0x0C;           																	// 3) enable alt funct on PB2,3       0b00001100
    GPIO_PORTB_ODR_R |= 0x08;             																	// 4) enable open drain on PB3 only

    GPIO_PORTB_DEN_R |= 0x0C;             																	// 5) enable digital I/O on PB2,3
	//    GPIO_PORTB_AMSEL_R &= ~0x0C;          																// 7) disable analog functionality on PB2,3

                                                                            // 6) configure PB2,3 as I2C
	//  GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFFFF00FF)+0x00003300;
 	GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFFFF00FF)+0x00002200;    //TED
    I2C0_MCR_R = I2C_MCR_MFE;                      													// 9) master function enable
    I2C0_MTPR_R = 0b0000000000000101000000000111011;                       	// 8) configure for 100 kbps clock (added 8 clocks of glitch suppression ~50ns)
	//    I2C0_MTPR_R = 0x3B;                                        						// 8) configure for 100 kbps clock
        
}


void PortH_Init(void)	// For Rotating Stepper
{	
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R7;		              
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R7) == 0){};	      
  
	GPIO_PORTH_DIR_R = 0x0F;														
	GPIO_PORTH_DEN_R = 0x0F;                        		
	return;
}

void PortJ_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R8;                 // Activate the clock for Port J
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R8) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTJ_DIR_R = 0b00000000;       								      // Enable PJ0, PJ1 as inputs 
  	GPIO_PORTJ_DEN_R = 0b00000011;														// Enable PJ0, PJ1 as digital pins
	GPIO_PORTJ_PUR_R = 0b00000011;														// Enables pullup resistors to make buttons active low, matching external buttons


	return;
}

void SpinMotor(int* fullSteps, float* motorDegrees){
	uint32_t delay = 2000;														

	// Clockwise rotation :0
	GPIO_PORTH_DATA_R = 0x03;
	*motorDegrees += 0.1758;
	
	SysTick_Wait1us(delay);											
		
	GPIO_PORTH_DATA_R = 0x06;
	*motorDegrees += 0.1758;
		
	SysTick_Wait1us(delay);
	
	GPIO_PORTH_DATA_R = 0x0C;
	*motorDegrees += 0.1758;
		
	SysTick_Wait1us(delay);
		
	GPIO_PORTH_DATA_R = 0x09;
	*motorDegrees += 0.1758;
		
	SysTick_Wait1us(delay);
	*fullSteps += 4;		
}

void SpinMotorCCW(int* fullSteps, float* motorDegrees){
	uint32_t delay = 2000;	
	
	GPIO_PORTH_DATA_R = 0x09;
	*motorDegrees += 0.1758;
			
			
	SysTick_Wait1us(delay);	
			
	GPIO_PORTH_DATA_R = 0x0C;
	*motorDegrees += 0.1758;
			
	SysTick_Wait1us(delay);
			
	GPIO_PORTH_DATA_R = 0x06;
	*motorDegrees += 0.1758;

	SysTick_Wait1us(delay);
			
	GPIO_PORTH_DATA_R = 0x03;
	*motorDegrees += 0.1758;
			
	SysTick_Wait1us(delay);
			
	*fullSteps -= 4;	
}

void dataButton(void){
	if ((GPIO_PORTJ_DATA_R & 0x1) == 0){
		SysTick_Wait10ms(25);																		// wait time for debounce
		dataButt = !dataButt;
	}
}

void stepperScanButton(void){
	if ((GPIO_PORTJ_DATA_R & 0x2) == 0){
		SysTick_Wait10ms(25);																		// wait time for debounce
		stepperScanButt = !stepperScanButt;
	}
}