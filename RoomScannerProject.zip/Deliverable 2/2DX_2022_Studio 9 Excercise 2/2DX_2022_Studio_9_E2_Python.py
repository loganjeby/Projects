#Modify the following line with your own serial port details
#   Currently set COM3 as serial port at 115.2kbps 8N1
#   Refer to PySerial API for other options.  One option to consider is
#   the "timeout" - allowing the program to proceed if after a defined
#   timeout period.  The default = 0, which means wait forever.


import serial
import open3d as o3d
import numpy as np

s = serial.Serial('COM5', 115200, timeout = 10)

print("Opening: " + s.name)

# reset the buffers of the UART port to delete the remaining data in the buffers
s.reset_output_buffer()
s.reset_input_buffer()

X = []
Y = []
Z = []

# wait for user's signal to start the program
input("Press Enter to start communication...")
# send the character 's' to MCU via UART
# This will signal MCU to start the transmission
s.write('s'.encode())
# recieve 8 measurements from UART of MCU
for i in range(10):
    x = s.readline()
    print(x.decode())

for i in range(2):
    x = s.readline()
    print(x.decode())
    X.append(0)
    Y.append(float(x.decode()))
    Z.append(0)

       
for i in range(2):
    x = s.readline()
    print(x.decode())
    X.append(0)
    Y.append(float(x.decode())/2)
    Z.append(float(x.decode())/2)

for i in range(2):
    x = s.readline()
    print(x.decode())
    X.append(30)
    Y.append(0)
    Z.append(float(x.decode()))

for i in range(2):
    x = s.readline()
    print(x.decode())
    X.append(30)
    Y.append(-float(x.decode())/2)
    Z.append(float(x.decode())/2)

for i in range(3):
    x = s.readline()
    print(x.decode())
# the encode() and decode() function are needed to convert string to bytes
# because pyserial library functions work with type "bytes"

#close the port
print("Closing: " + s.name)
s.close()

print("X: ", X)
print("Y: ", Y) 
print("Z: ", Z)

# Create a mesh grid where X spans the grid and Y, Z determine the shape
X = np.linspace(0, 1000, len(X))  # Adjust the range and number of points as needed
Y = np.array(Y)  # Ensure Y is a NumPy array
Z = np.array(Z)  # Ensure Z is a NumPy array

# Generate the mesh grid
X, Y, Z = np.meshgrid(X, Y, Z, indexing='xy')

# Flatten the arrays and combine them into points
points = np.array([X.flatten(), Y.flatten(), Z.flatten()]).T

lines = []
cols = len(Y)
rows = len(Z)
for i in range(rows-1):
    for j in range(cols-1):
        idx = i*cols + j
        lines.append([idx, idx+1])
        lines.append([idx, idx+cols])

line_set = o3d.geometry.LineSet()
line_set.lines = o3d.utility.Vector2iVector(lines)
line_set.colors = o3d.utility.Vector3dVector(np.array([[0, 0, 1] for i in range(len(lines))]))
line_set.points = o3d.utility.Vector3dVector(points)
o3d.visualization.draw_geometries([line_set])
