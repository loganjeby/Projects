#Modify the following line with your own serial port details
#   Currently set COM3 as serial port at 115.2kbps 8N1
#   Refer to PySerial API for other options.  One option to consider is
#   the "timeout" - allowing the program to proceed if after a defined
#   timeout period.  The default = 0, which means wait forever.

import serial
import open3d as o3d
import numpy as np
import math

points = []
point = []

PhaseAngle = 0                  # Phase angle of the motor in degrees
X = 0                           # X coordinate of the point
scans = 0                       # Number of full 360 scans done 

s = serial.Serial('COM5', 115200, timeout = 10)

print("Opening: " + s.name)

# reset the buffers of the UART port to delete the remaining data in the buffers
s.reset_output_buffer()
s.reset_input_buffer()

# wait for user's signal to start the program
input("Press Enter to start communication...")
# send the character 's' to MCU via UART
# This will signal MCU to start the transmission
s.write('s'.encode())
# recieve 8 measurements from UART of MCU
for i in range(10):
    x = s.readline()
    print(x.decode())

while(scans < 3):
    input("Press Enter to start communication...")
    # send the character 's' to MCU via UART
    # This will signal MCU to start the transmission
    s.write('s'.encode())
    print("Starting scan: ", scans)
    while(PhaseAngle < 512):
        x = s.readline()
        data = x.decode()
        while(data == "St\n" or data == "Sc\n" or data == "D\n"):
            x = s.readline()
            data = x.decode()
            print(data)
        print(data)
        angle = (PhaseAngle/512)*2*math.pi
        r = int(data)
        y = r*math.cos(angle)
        z = r*math.sin(angle)
        point = [X, y, z]
        points.append(point)
        PhaseAngle += 8
    X += 600
    scans += 1
    PhaseAngle = 0

# the encode() and decode() function are needed to convert string to bytes
# because pyserial library functions work with type "bytes"

# Close the port
print("Closing: " + s.name)
s.close()

print("Points: ", points)

# Convert points to Open3D format and visualize
pcd = o3d.geometry.PointCloud()
pcd.points = o3d.utility.Vector3dVector(points)

# Create lines between points along the X-axis
lines = []
count = 0
while count < 3:
    for i in range(0, 63):
        lines.append([i + count * 64, i + count * 64 + 1])
    lines.append([count * 64, count * 64 + 63])
    count += 1

for i in range(len(points) - 64):
    lines.append([i, i + 64])

# Create a LineSet object
line_set = o3d.geometry.LineSet()
line_set.points = o3d.utility.Vector3dVector(points)
line_set.lines = o3d.utility.Vector2iVector(lines)

# Visualize the point cloud with lines
o3d.visualization.draw_geometries([line_set])


