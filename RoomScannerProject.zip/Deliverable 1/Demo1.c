
#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "Systick.h"
#include "PLL.h"

// Function Prototypes
void PortM_Init(void);
void PortJ_Init(void);
void PortN_Init(void);
void PortF_Init(void);
void PortH_Init(void);

void spin_CW(void);
void spin_CCW(void);
void button_0(void);
void button_1(void);
void button_2(void);
void button_3(void);

// Global Variables
_Bool motorState = 0; // 0 = off, 1 = on
_Bool motorDir = 0; // 0 = CW, 1 = CCW
_Bool flashDeg = 0; // 0 = 11.25, 1 = 45
int stepTurned = 0; // For button 3 return steps amount
double flashCheck = 0; // for LED 3 flashing


int main (void){
	PLL_Init();
	SysTick_Init();
	
	PortM_Init();
	PortJ_Init();
	PortN_Init();
	PortF_Init();
	PortH_Init();
	/* 
		LEDs:
			LED0 = GPIO_PORTN_DATA_R & 0x2 = D1
			LED1 = GPIO_PORTN_DATA_R & 0x1 = D2
			LED2 = GPIO_PORTF_DATA_R & 0x10 = D3
			LED3 = GPIO_PORTF_DATA_R & 0x1 = D4
		Buttons:
			Button 0: GPIO_PORTJ_DATA_R & 0x1
									if (GPIO_PORTJ_DATA_R & 0x1) == 0, button pressed
			Button 1: GPIO_PORTJ_DATA_R & 0x2
									if (GPIO_PORTJ_DATA_R & 0x2) == 0, button pressed
			Button 2: GPIO_PORTM_DATA_R & 0x1
									if (GPIO_PORTM_DATA_R & 0x1) == 0, button pressed
			Button 3: GPIO_PORTM_DATA_R & 0x2
									if (GPIO_PORTM_DATA_R & 0x2) == 0, button pressed
	*/
	
	GPIO_PORTF_DATA_R = 0x0000;
	GPIO_PORTN_DATA_R = 0x0000;
	
	while(1){
		button_0(); 																						// Constantly checking button 0 to determine whether motor state is being changed
		if(motorState == 0){ 																		// if motor state is 0, ensure LEDs and other variables are all 0
			GPIO_PORTN_DATA_R = 0x0000;
			GPIO_PORTF_DATA_R = 0x0000;
			motorDir = 0;
			flashDeg = 0;
			flashCheck = 0;
		}
		if(motorState == 1){ 																		// If motor state is 1, set LED0 on, check other buttons, react accordingly
			GPIO_PORTN_DATA_R = 0x2;
			button_1();
			button_2();
			if (motorDir == 0){																		// If motor CCW, set CW, else set CCW. Turn on or off LED1 acordingly
				GPIO_PORTN_DATA_R = 0x3;
				spin_CW();
			}
			if (motorDir == 1){
				GPIO_PORTN_DATA_R = 0x2;
				spin_CCW();
			}
			if (flashDeg == 0){																		// If flashDeg 0, flash LED3 every ~11.25 deg, else every ~45
				GPIO_PORTF_DATA_R = 0x10;														// Set LED2 accordingly
				if ((flashCheck >= 11.15 && flashCheck <= 11.35) || (flashCheck <= -11.15 && flashCheck >= -11.35)){
					GPIO_PORTF_DATA_R = 0x11;
					SysTick_Wait10ms(1);
					flashCheck = 0;
				}
			}
			if (flashDeg == 1){
				GPIO_PORTF_DATA_R = 0x00;
				if ((flashCheck >= 44.9 && flashCheck <= 45.1) || (flashCheck <= -44.9 && flashCheck >= -45.1)){
					GPIO_PORTF_DATA_R = 0x01;
					SysTick_Wait10ms(1);
					flashCheck = 0;
				}
			}	
			if ((stepTurned >= 2048) || (stepTurned <= -2048)){		// if stepTurned over one rotation, return to 0
				stepTurned = 0;
			}
			button_3();																						// Check button 3 here to avoid if statements after completion
		}
	}
}

void PortM_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11;                 // Activate the clock for Port M
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTM_DIR_R = 0x0;       								      			// Enable PM0, PM1 as inputs 
  GPIO_PORTM_DEN_R = 0x3;																		// Enable PM0, PM1 as digital pins

	
	return;
}

void PortJ_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R8;                 // Activate the clock for Port J
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R8) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTJ_DIR_R = 0b00000000;       								      // Enable PJ0, PJ1 as inputs 
  GPIO_PORTJ_DEN_R = 0b00000011;														// Enable PJ0, PJ1 as digital pins
	GPIO_PORTJ_PUR_R = 0b00000011;														// Enables pullup resistors to make buttons active low, matching external buttons


	return;
}

//Enable LED D1, D2. Remember D1 is connected to PN1 and D2 is connected to PN0
void PortN_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12;                 // Activate the clock for Port N
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R12) == 0){};				// Allow time for clock to stabilize
		
	GPIO_PORTN_DIR_R=0x3;																			// Enable PN0 and PN1 as outputs													
	GPIO_PORTN_DEN_R=0x3;																			// Enable PN0 and PN1 as digital pins
	return;
}

//Enable LED D3, D4. Remember D3 is connected to PF4 and D4 is connected to PF0
void PortF_Init(void){
  SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5;                 	// Activate the clock for Port F
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R5) == 0){};					// Allow time for clock to stabilize
		
	GPIO_PORTF_DIR_R=0x11;																		// Enable PF0 and PF4 as outputs
	GPIO_PORTF_DEN_R=0x11;																		// Enable PF0 and PF4 as digital pins
	return;
}

void PortH_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R7;									// activate clock for Port H
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R7) == 0){};					// allow time for clock to stabilize
	GPIO_PORTH_DIR_R |= 0x0F;        													// configure Port H pins (PH0-PH3) as output
  GPIO_PORTH_AFSEL_R &= ~0x0F;     													// disable alt funct on Port H pins (PH0-PH3)
  GPIO_PORTH_DEN_R |= 0x0F;        													// enable digital I/O on Port H pins (PH0-PH3)
																														// configure Port H as GPIO
  GPIO_PORTH_AMSEL_R &= ~0x0F;     													// disable analog functionality on Port H	pins (PH0-PH3)	
	return;
}

void spin_CW(void){																					// Port data change order spins clockwise
	uint32_t delay = 200;																			// Spins at okay pace without overloading motor
		
	GPIO_PORTH_DATA_R = 0b00000011;
	flashCheck += 0.1758;																			// Adds degrees turned to flashCheck 
	SysTick_Wait10us(delay);			
	GPIO_PORTH_DATA_R = 0b00000110;			
	flashCheck += 0.1758;
	SysTick_Wait10us(delay);
	GPIO_PORTH_DATA_R = 0b00001100;			
	flashCheck += 0.1758;
	SysTick_Wait10us(delay);
	GPIO_PORTH_DATA_R = 0b00001001;			
	flashCheck += 0.1758;
	SysTick_Wait10us(delay);
	stepTurned += 4;																					// Adds steps turned to stepTurned
}

void spin_CCW(void){																				// Port data change order spins counter-clockwise
		uint32_t delay = 200;																		// Spins at okay pace without overloading motor
	
	GPIO_PORTH_DATA_R = 0b00001001;
	flashCheck -= 0.1758;																			// Subtracts degrees turned from flashCheck
	SysTick_Wait10us(delay);			
	GPIO_PORTH_DATA_R = 0b00001100;			
	flashCheck -= 0.1758;
	SysTick_Wait10us(delay);
	GPIO_PORTH_DATA_R = 0b00000110;			
	flashCheck -= 0.1758;
	SysTick_Wait10us(delay);
	GPIO_PORTH_DATA_R = 0b00000011;			
	flashCheck -= 0.1758;
	SysTick_Wait10us(delay);
	stepTurned -= 4;																					// Subtracts steps turned from stepTurned
}


void button_0(void){																				// toggles motorState if button 0 (j0) is pressed
	if ((GPIO_PORTJ_DATA_R & 0x1) == 0){
		SysTick_Wait10ms(25);																		// wait time for debounce
		motorState = !motorState;
	}
}
void button_1(void){																				// toggles motorDir if button 1 (j1) is pressed
	if ((GPIO_PORTJ_DATA_R & 0x2) == 0){
		SysTick_Wait10ms(25);																		// wait time for debounce
		motorDir = !motorDir;
	}
}
void button_2(void){																				// toggles flashDeg if button 2 (m0) is pressed
	if ((GPIO_PORTM_DATA_R & 0x1) == 0){											
		SysTick_Wait10ms(25);																		// wait time for debounce
		flashDeg = !flashDeg;																		
		flashCheck = 0;																					// resets flash check so led flashes at appropriate intervals
	}																													// can be changed if not what is wanted by removing line
}
void button_3(void){																				// returns home if button 3 (m1) is pressed
	if ((GPIO_PORTM_DATA_R & 0x2) == 0){
		SysTick_Wait10ms(25);																		// wait time for debounce
		while(stepTurned != 0){																	// while loop to ensure no interrupt from other buttons
			if(stepTurned < 0){ 																	// majority spin is CW
				spin_CW();
			}	
			else if (stepTurned > 0){															// majority spin is CCW
				spin_CCW();
			}
		}
		motorState = 0; // 0 = off, 1 = on											// resets all variables once home, stopping motor
		motorDir = 0; // 0 = CW, 1 = CCW
		flashDeg = 0; // 0 = 11.25, 1 = 45
		stepTurned = 0;
		flashCheck = 0;
	}
}